def mult_scalar(matrix, scale):
	return [[]]

def mult_matrix(a, b):
	return [[]]
	
def euclidean_dist(a,b):
	return -1